/************************************************************************************************
 *  Author:  amg16h Adam Garcia
 *  Course:  CS375 Software Engineering II
 *  Date:    Fall 2020
 *
 *  Program: CompressionTest
 *  Compile: javac CompressionTest.java
 *  Execute: java -cp target/classes CompressionTest.java
 *  
 *  Note   : TarsnTest.java will extract all the files contained in the given archive.
 * 
 * 			 The fllowing classes were desgined by Robert Sedgewick and Kevin Wayne:
 * 			 BinaryDump.java BinaryIn.java BinaryOut.java BinaryStdIn.java 
 * 			 BinaryStdOut.java StdIn.java StdOut.java
 * 
 * 			 To view archive contents in terminal run:
 * 				Compile: javac BinaryDump.java
 * 				Execute: java -cp target/classes BinaryDump 16 < <archiveFileName>
 *
 ************************************************************************************************/

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.assertFalse;
import org.junit.Before;
import org.junit.After;
import org.junit.Test;
import org.junit.Rule;
import org.junit.runner.Description;
import org.junit.rules.TestRule;
import org.junit.rules.TestWatcher;
import org.junit.FixMethodOrder;
import org.junit.runners.MethodSorters;

//import sun.reflect.misc.FieldUtil;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileWriter;
import java.io.PrintStream;
import java.io.InputStream;
import java.io.IOException;
import java.lang.Math.*;
import java.util.Random;

import org.apache.commons.lang3.RandomStringUtils;
import org.apache.commons.io.FileUtils;

public class CompressionTest {
    private final ByteArrayOutputStream outContent = new ByteArrayOutputStream();
    private final ByteArrayOutputStream errContent = new ByteArrayOutputStream();
    private final PrintStream originalOut = System.out;
    private final PrintStream originalErr = System.err;
    private final String testDir = "Resources" + File.separator + "Tests" + File.separator;
    private final String SHsolutionDir = "Resources" + File.separator + "SH_Solutions" + File.separator;
    private final String SLsolutionDir = "Resources" + File.separator + "SL_Solutions" + File.separator;
    private final String SAsolutionDir = "Resources" + File.separator + "SA_Solutions" + File.separator;
    private final String DsolutionDir = "Resources" + File.separator + "D_Solutions" + File.separator;
    private final String dynDir = "Files" + File.separator + "DynamicTest" + File.separator;

    @Rule
    public TestRule watcher =
    	new TestWatcher() {
    	    protected void starting(Description description) {
            System.out.println("Starting test: " + description.getMethodName());
    	}
    };

    @Before
    public void setUpStreams() {
        System.setOut(new PrintStream(outContent));
        System.setErr(new PrintStream(errContent));
    }

    @After
    public void restoreStreams() throws IOException{
        System.setOut(originalOut);
        System.setErr(originalErr);
    }

    /*
     *
     * TESTING FUNCTIONS
     * 
    */

    // returns name of randomly generated file
    public String randomFileGenerator() {
        
        // generate random string for filename
        int length = 10;
        boolean useLetters = true;
        boolean useNumbers = false;
        String generatedString = dynDir + RandomStringUtils.random(length, useLetters, useNumbers);

        try {
            // create new file
            File randomFile = new File(generatedString);
            randomFile.createNewFile();
            // create file contents
            randomContentGenerator(randomFile);
            
        } catch (Exception e) {
            System.out.println("Random File Generator Failed");
        }
        return generatedString;
    }

    // fill input file with random content
    public void randomContentGenerator(File out) {
        FileWriter filewriter = null;
        Random random = new Random();
        int n = random.nextInt(50);

        try {
            filewriter = new FileWriter(out);

            BufferedWriter writer = new BufferedWriter(filewriter);
            char line;
            while (n > 0) {
                line = (char) (' ' + random.nextInt(94));
                writer.write(line);
                n--;
            }
            writer.close();

        } catch (Exception e) {
            e.printStackTrace();
            System.exit(0);
        }
    }

    public boolean compareFolders(String[] args) {
		try {
			File sourceFolder = new File(args[0]);
			File destFolder = new File(args[1]);

			// checks that Source Folder and Destination Folder are Directories
			if(!(sourceFolder.exists() && sourceFolder.isDirectory()
			   && destFolder.exists() && destFolder.isDirectory())) {
					return false;
			}
			
			// creates a string of everything in directories
			String[] sourceFiles = sourceFolder.list();
			String[] destFiles = destFolder.list();

			// compares array of files
			for (int i = 0; i < sourceFiles.length && i < destFiles.length; i++) {
				File file1 = new File(sourceFiles[i]);
				File file2 = new File(destFiles[i]);
				Boolean isTwoEqual = FileUtils.contentEquals(file1, file2);

				// if a single file match is false
				if(!isTwoEqual)
					return false;
			}
		} catch (Exception e) {
			return false;
		}
		return true;
    }
    










    /*
     *
     * SchubsH TEST CASES:
     * 
     * 
     * Test 1: Normal case
     * Test 2: The file(s) to be compressed are empty
     * Test 3: The file(s) to be compressed do not exist *
     * Test 4: The destination file already exists
     * Test 5: One of the files to be compressed is instead a directory and should therefore fail *
     * Test 6: The file(s) to be compressed contain many characters
     * Test 7: The file(s) to be compressed contain characters such as spaces and line endings
     * Test 8: Any combination of the files to be compressed containing spaces, line endings, being empty, not existing, being directories, containing many characters, or containing few characters.
     * Test 9: The user passes in the wrong amount of arguments
     * Test 10: Dynamic Test Case
     * 
    */

    // TEST 1,2,4,6,7
    @Test
    public void SchubsHpassingTestCases() {
        String tests[] = {"test1-1.txt", "test1-2.txt",
                          "test2-1.txt", "test2-2.txt",
                          "test4-1.txt", "test4-2.txt",
                          "test6-1.txt", "test6-2.txt",
                          "test7-1.txt", "test7-2.txt"};

        for(int i = 0; i < tests.length; i = i+2) {
            String[] args = {testDir + tests[i], testDir + tests[i+1]}; // files in test directory

            SchubsH.main(args); // compress

            try {
                // compares first result file and its solution file
                File file1 = new File(args[0] + ".hh");
                File file2 = new File(SHsolutionDir + tests[i] + ".hh");

                assertTrue(FileUtils.contentEquals(file1, file2));

                // compares second result file and its solution file
                File file3 = new File(args[1] + ".hh");
                File file4 = new File(SHsolutionDir + tests[i+1] + ".hh");
                assertTrue(FileUtils.contentEquals(file3, file4));

            } catch (Exception e) {
                assert(false);
            }
        }
    }

    // TEST 9
    @Test
    public void SchubsHwrongArguments() {
        String[] emptyArgs = {};

        SchubsH schubsH = new SchubsH();
        schubsH.main(emptyArgs);

        assertFalse(schubsH.correctNumInput());
    }







    /*
     *
     * SchubsL TEST CASES:
     * 
     * 
     * Test 1: Normal case
     * Test 2: The file(s) to be compressed are empty
     * Test 3: The file(s) to be compressed do not exist *
     * Test 4: The destination file already exists
     * Test 5: One of the files to be compressed is instead a directory and should therefore fail *
     * Test 6: The file(s) to be compressed contain many characters
     * Test 7: The file(s) to be compressed contain characters such as spaces and line endings
     * Test 8: Any combination of the files to be compressed containing spaces, line endings, being empty, not existing, being directories, containing many characters, or containing few characters.
     * Test 9: The user passes in the wrong amount of arguments
     * Test 10: Dynamic Test Case
     * 
    */

    // TEST 1,2,4,6,7
    @Test
    public void SchubsLpassingTestCases() {
        String tests[] = {"test1-1.txt", "test1-2.txt",
                          "test2-1.txt", "test2-2.txt",
                          "test4-1.txt", "test4-2.txt",
                          "test6-1.txt", "test6-2.txt",
                          "test7-1.txt", "test7-2.txt"};

        for(int i = 0; i < tests.length; i = i+2) {
            String[] args = {testDir + tests[i], testDir + tests[i+1]}; // files in test directory

            SchubsL.main(args); // compress

            try {
                // compares first result file and its solution file
                File file1 = new File(args[0] + ".ll");
                File file2 = new File(SLsolutionDir + tests[i] + ".ll");

                assertTrue(FileUtils.contentEquals(file1, file2));

                // compares second result file and its solution file
                File file3 = new File(args[1] + ".ll");
                File file4 = new File(SLsolutionDir + tests[i+1] + ".ll");
                assertTrue(FileUtils.contentEquals(file3, file4));

            } catch (Exception e) {
                assert(false);
            }
        }
    }

    // TEST 9
    @Test
    public void SchubsLwrongArguments() {
        String[] emptyArgs = {};

        SchubsL schubsL = new SchubsL();
        schubsL.main(emptyArgs);
        
        assertFalse(schubsL.correctNumInput());
    }









    /*
     *
     * SchubsArc TEST CASES:
     * 
     * 
     * Test 1: Normal case
     * Test 2: The file(s) to be Tars'd are empty
     * Test 3: The file(s) to be Tars'd do not exist *
     * Test 4: The destination archive already exists
     * Test 5: One of the files to be Tars'd is instead a directory and should therefore fail *
     * Test 6: The file(s) to be Tars'd contain many characters
     * Test 7: The file(s) to be Tars'd contain characters such as spaces and line endings
     * Test 8: Any combination of the files to be Tars'd containing spaces, line endings, being empty, not existing, being directories, containing many characters, or containing few characters.
     * Test 9: The user passes in the wrong amount of arguments
     * Test 10: Dynamic Test Case
     * 
    */

    // TEST 1,2,4,6,7
    @Test
    public void SchubsArcpassingTestCases() {
        String tests[] = {"test1_Archive", "test1-1.txt", "test1-2.txt",
                          "test2_Archive", "test2-1.txt", "test2-2.txt",
                          "test4_Archive", "test4-1.txt", "test4-2.txt",
                          "test6_Archive", "test6-1.txt", "test6-2.txt",
                          "test7_Archive", "test7-1.txt", "test7-2.txt"};

        for(int i = 0; i < tests.length; i = i+3) {
            String[] args = {testDir + tests[i], testDir + tests[i+1], testDir + tests[i+2]}; // files in test directory

            SchubsArc.main(args); // archive

            try {
                // compares first result file and its solution file
                File file1 = new File(args[0] + ".zh");
                File file2 = new File(SAsolutionDir + tests[i] + ".zh");

                assertTrue(FileUtils.contentEquals(file1, file2));

            } catch (Exception e) {
                assert(false);
            }
        }
    }

        // TEST 9
        @Test
        public void SchubsArcwrongArguments() {
            String[] emptyArgs = {};
    
            SchubsArc schubsArc = new SchubsArc();
            schubsArc.main(emptyArgs);
            
            assertFalse(schubsArc.correctInput());
        }









    /*
     *
     * Deschubs TEST CASES:
     * 
     * Test 1: uncompress Huffman
     * Test 2: uncompress LZW
     * Test 3: unarchive with Huffman
     * Test 4: input file(s) do not exist *
     * Test 5: destination uncrompessed files already exist
     * Test 6: destination unarchived files already exist
     * Test 7: input to be uncompressed is a direcory and should therefore fail *
     * Test 8: incorrect number of inputs (zero inputs)
     * Test 9: incorrect file input (wrong extention, not .zh, .hh, .ll)
     * Test 10: Dynamic Test Case
     * 
     * 
    */

    // // TEST 1
    // @Test
    // public void DeschubsHuffmanTestCases() {
    //     String tests[] = {"test1-1.txt.hh",
    //                       "test1-1.txt.ll"};
    //                      // "test1_archive"};

    //     String[] args = {testDir + tests[i], testDir + tests[i+1]}; // files in test directory

    //     Deschubs.main(args); // uncompress

    //     try {
    //         // compares first result file and its solution file
    //         File file1 = new File(args[0] + ".ll");
    //         File file2 = new File(SLsolutionDir + tests[i] + ".ll");

    //         assertTrue(FileUtils.contentEquals(file1, file2));

    //         // compares second result file and its solution file
    //         File file3 = new File(args[1] + ".ll");
    //         File file4 = new File(SLsolutionDir + tests[i+1] + ".ll");
    //         assertTrue(FileUtils.contentEquals(file3, file4));

    //     } catch (Exception e) {
    //         assert(false);
    //     }    
    // }





}