/*************************************************************************
 *  Author:       amg16h Adam Garcia
 *  Course:       CS375 Software Engineering II
 *  Date:         Fall 2020
 * 
 *  Program:      SchubsL
 *  Compile:      javac SchubsL.java
 *  Execute:      java -cp target/classes SchubsL.java
 *  Dependencies: BinaryIn.java BinaryOut.java TST.java
 *
 *  Compress files using LZW.
 *
 *
 *************************************************************************/

import java.io.File;

public class SchubsL {

    // testing functions
    private static Boolean inputCorrect = true;
    public Boolean correctNumInput() {return inputCorrect;}


    private static final int R = 256;        // number of input chars
    private static final int L = 4096;       // number of codewords = 2^W
    private static final int W = 12;         // codeword width

    public static void compress(BinaryIn in, BinaryOut out) { 
        String input = in.readString();
        TST<Integer> st = new TST<Integer>();
        for (int i = 0; i < R; i++)
            st.put("" + (char) i, i);
        int code = R+1;  // R is codeword for EOF

        while (input.length() > 0) {
            String s = st.longestPrefixOf(input);  // Find max prefix match s.
            out.write(st.get(s), W);      // Print s's encoding.
            int t = s.length();
            if (t < input.length() && code < L)    // Add s to symbol table.
                st.put(input.substring(0, t + 1), code++);
            input = input.substring(t);            // Scan past s in input.
        }
        out.write(R, W);
        out.close();
    }

    public static void main(String[] args) {
        BinaryIn in = null;
        BinaryOut out = null;
        File currentFile;

        // input must be one or more files
        if(args.length < 1) {
			System.out.println("Incorrect number of filenames. At least one file is required.");
			inputCorrect = false;
			return;
		}

        // cycles through args filenames
        for (int i = 0; i < args.length; i++) {
            try {
                currentFile = new File(args[i]);

                // if current file doesnt exist or isnt a file
                if (!currentFile.exists() || !currentFile.isFile()) {
                    System.out.println(args[i] + " could not be compressed because it was not a file");
                }
                // if current file is empty
                else if (currentFile.length() == 0) {
                    System.out.println(args[i] + " could not be compressed because it was empty");
                }
                // compress current file
                else {
                    in = new BinaryIn(args[i]);
                    out = new BinaryOut(args[i] + ".ll");
                    compress(in, out);
                }
            } finally {
                if (out != null)
                    out.close();
            }
        }   
    }
}